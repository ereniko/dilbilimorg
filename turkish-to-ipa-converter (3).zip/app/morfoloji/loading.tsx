"use client"

export default function Loading() {
  return null
}
